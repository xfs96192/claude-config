from gmssl import sm4
import base64


class SM4Crypto:
    BLOCK_SIZE = 16

    def __init__(self, key: str):
        self.secret_key = self.prepare_key(key)

    def prepare_key(self, key: str) -> bytes:
        key_bytes = key.encode("utf-8")
        if len(key_bytes) > self.BLOCK_SIZE:
            return key_bytes[:self.BLOCK_SIZE]
        elif len(key_bytes) < self.BLOCK_SIZE:
            return key_bytes.ljust(self.BLOCK_SIZE, b'\0')
        return key_bytes

    def encrypt(self, plaintext: str) -> str:
        cryptor = sm4.CryptSM4()
        cryptor.set_key(self.secret_key, sm4.SM4_ENCRYPT)
        encrypted_bytes = cryptor.crypt_ecb(plaintext.encode("utf-8"))  # ECB 模式加密
        return base64.urlsafe_b64encode(encrypted_bytes).decode("utf-8").rstrip("=")

    def decrypt(self, encrypted_base64: str) -> str:
        encrypted_base64 += "=" * ((4 - len(encrypted_base64) % 4) % 4)
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_base64)
        cryptor = sm4.CryptSM4()
        cryptor.set_key(self.secret_key, sm4.SM4_DECRYPT)
        return cryptor.crypt_ecb(encrypted_bytes).decode("utf-8")
